package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.FrameBottomNavBar
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.ChallengeDetailScreen
import com.example.ui.screens.ChallengesScreen
import com.example.ui.screens.DiscoverRoomsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewCreationScreen
import com.example.ui.screens.PostProcessScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RoomDetailScreen
import com.example.ui.screens.SharedStoryScreen
import com.example.ui.theme.FrameTheme
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val viewModel = FrameViewModel(application)

        setContent {
            FrameTheme {
                FrameApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun FrameApp(viewModel: FrameViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()

    BackHandler(enabled = currentScreen != ScreenDestination.HOME_FEED) {
        viewModel.navigateBack()
    }

    val showBottomBar = when (currentScreen) {
        ScreenDestination.HOME_FEED,
        ScreenDestination.ROOMS_DISCOVER,
        ScreenDestination.CHALLENGES_HUB,
        ScreenDestination.PROFILE -> true
        else -> false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                FrameBottomNavBar(
                    selectedTab = currentTab,
                    onTabSelected = { tab ->
                        viewModel.selectTab(tab)
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenDestination.HOME_FEED -> HomeScreen(viewModel = viewModel)
                ScreenDestination.ROOMS_DISCOVER -> DiscoverRoomsScreen(viewModel = viewModel)
                ScreenDestination.ROOM_DETAIL -> RoomDetailScreen(viewModel = viewModel)
                ScreenDestination.CHALLENGES_HUB -> ChallengesScreen(viewModel = viewModel)
                ScreenDestination.CHALLENGE_DETAIL -> ChallengeDetailScreen(viewModel = viewModel)
                ScreenDestination.SHARED_STORY -> SharedStoryScreen(viewModel = viewModel)
                ScreenDestination.POST_PROCESS -> PostProcessScreen(viewModel = viewModel)
                ScreenDestination.NEW_CREATION -> NewCreationScreen(viewModel = viewModel)
                ScreenDestination.ACTIVITY -> ActivityScreen(viewModel = viewModel)
                ScreenDestination.PROFILE -> ProfileScreen(viewModel = viewModel)
            }
        }
    }
}
