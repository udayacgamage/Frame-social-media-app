package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.StoryMomentEntity
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel

@Composable
fun SharedStoryScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val moments by viewModel.storyMoments.collectAsState()
    val momentInput by viewModel.momentInput.collectAsState()

    val contributors = listOf(
        "https://lh3.googleusercontent.com/aida-public/AB6AXuAfQOlqbYCJwTQuKaH9pCqXyZk_Aiyi7AxCGl877_LpQ5tNAPIVpPMx-1whBwF172E8lPF_Dq8h27nF1Kzlc8OXr-OK1Rjwg1CyBdZCiPqGdGQWTkoOk0xNLuUr9VZyfKBtTSDb76fnK1094q27791EAoyjKxyfxajfsVt0kphyWiJJzvoyTwQUmzM3I9nBT6Swl0fGu7QjHf7kaT2glj16zPbwUW6nXqC7QWDPDx1VeFp9RSkAGOID6eJJnSuCZGW7JpDQe6sURw",
        "https://lh3.googleusercontent.com/aida-public/AB6AXuB22aVdnEFpmuHdn1iI2MeuXcB_puv8Hh_AFzBRm4M0mIUo5g_oKfibjqgj1nkcrPbkdCLufPTLVzDigfB63Y72_PKl_qYtQeXdDx124GP8-MaRhnNFF8b4hbhl5df6e2Zs1bavEhcmgRM6aBkq6lsMrILHWENKgHsF01O5I4YNUnLJvDvxPoLEBOTIK35Wmt2UBldB7mDJ9n2n8iqpb80SXOgqHiGdCaOD3D2v5PWNyxVl4MtnnPYAZ14AaeafYecrQGIRpwoPsg",
        "https://lh3.googleusercontent.com/aida-public/AB6AXuAkVvzYifPwFTC0MlEWW582ICRuq2Tos_WgWLAz56fhVF_0Vhwm4ZHkS6CLHjwuZtLn4leG2J959nJxUpnVJPoh4YpzlqAW-rkack3e8tIh8Dcj1wO8f-KpUB3beFVV9POPE3Wedw_SovcuOZPuCjTdh2qRuQIFPynwCXQlldUlec_Qe-qXr0ij7jOL9_8D6nHqOeP9PaahL_0OeQQ6wQ9XPiA94mIcZc5xl2JrWUf1j_lrMGJ8Vaf4tZZ0XZIlm64gJdRA5FbC-A",
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBkOqajNNe0srkDvQfUZxvvnVCFTEf-73CHcrTqf1RaCCTGJ_JB5jVThOIZbgzPTDu40qDPWEAod2yEt_x7cLLHGh7CH9GJA6TiYnHms0ItQoPQCbCShGJ4wfTlbdjAL_5GC2AXWR_9bEuW8p0OXSyXnq6iIFUtKA6b16MbPnbLrkg-slESQGUIHOhUHRCItHOQd5TyH5O6pVwJz8t1mXvXqYggRn2mA4b9j3gjI_NPImctgWFFkouUlV_NqKFKL_oBGSWUCzrFdw"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("story_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF1C1B1B)
                )
            }

            Text(
                text = "Shared Story",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            Row {
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = Color(0xFF1C1B1B)
                    )
                }
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.MoreVert,
                        contentDescription = "More",
                        tint = Color(0xFF1C1B1B)
                    )
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Story Title & Contributors Header
            item {
                Column(modifier = Modifier.padding(bottom = 16.dp)) {
                    Text(
                        text = "A Weekend in Ella",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = Color(0xFF1C1B1B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Stacked avatar row
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                contributors.forEachIndexed { index, avatarUrl ->
                                    AsyncImage(
                                        model = avatarUrl,
                                        contentDescription = "Contributor",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .offset(x = (index * 22).dp)
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, Color.White, CircleShape)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width((contributors.size * 22 + 16).dp))

                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, FrameBorder, CircleShape)
                                    .clickable {},
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Invite Contributor",
                                    tint = Color(0xFF1C1B1B),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Button(
                            onClick = {},
                            colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Add Moment", fontSize = 11.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "4 contributors • Live collaborative story from the central highlands",
                        fontSize = 12.sp,
                        color = FrameTextMuted
                    )
                }

                HorizontalDivider(color = FrameBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Timeline items
            items(moments) { moment ->
                StoryTimelineCard(moment = moment)
                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // Bottom Add Moment Input Bar
        SurfaceInputBar(
            value = momentInput,
            onValueChange = { viewModel.setMomentInput(it) },
            onSendClick = { viewModel.submitNewMoment() }
        )
    }
}

@Composable
fun StoryTimelineCard(moment: StoryMomentEntity) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("timeline_moment_${moment.id}")
    ) {
        // Timeline Header: Author, Timestamp, Location
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = moment.authorHandle,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Location",
                    tint = FramePrimary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "${moment.timestamp} • ${moment.location}",
                    fontSize = 11.sp,
                    color = FrameTextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Photos
        if (moment.secondaryPhotoUrl != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AsyncImage(
                    model = moment.photoUrl,
                    contentDescription = "Photo 1",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(8.dp))
                )
                AsyncImage(
                    model = moment.secondaryPhotoUrl,
                    contentDescription = "Photo 2",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(8.dp))
                )
            }
        } else {
            AsyncImage(
                model = moment.photoUrl,
                contentDescription = "Photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(8.dp))
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Caption
        Text(
            text = moment.caption,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            color = Color(0xFF1C1B1B)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Reactions and Comments count
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (moment.reactionPill1 != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEBE7E7))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = moment.reactionPill1, fontSize = 11.sp, color = Color(0xFF1C1B1B))
                    }
                }
                if (moment.reactionPill2 != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEBE7E7))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = moment.reactionPill2, fontSize = 11.sp, color = Color(0xFF1C1B1B))
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.ChatBubbleOutline,
                    contentDescription = "Comments",
                    tint = FrameTextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${moment.commentsCount}",
                    fontSize = 11.sp,
                    color = FrameTextMuted
                )
            }
        }
    }
}

@Composable
fun SurfaceInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSendClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .imePadding()
    ) {
        HorizontalDivider(color = FrameBorder, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Outlined.CameraAlt,
                    contentDescription = "Attach Photo",
                    tint = Color(0xFF1C1B1B)
                )
            }

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text("Add a moment to this story...", fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp)
                    .testTag("story_moment_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FramePrimary,
                    unfocusedBorderColor = FrameBorder
                ),
                shape = RoundedCornerShape(20.dp),
                maxLines = 2
            )

            IconButton(
                onClick = onSendClick,
                modifier = Modifier.testTag("story_moment_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = FramePrimary
                )
            }
        }
    }
}
