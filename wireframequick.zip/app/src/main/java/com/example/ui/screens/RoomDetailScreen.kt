package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun RoomDetailScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.roomDetailTab.collectAsState()
    val posts by viewModel.posts.collectAsState()
    val streetPosts = posts.filter { it.roomName == "Street Photography" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("room_detail_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF1C1B1B)
                )
            }

            Row {
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share Room",
                        tint = Color(0xFF1C1B1B)
                    )
                }
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.MoreVert,
                        contentDescription = "More Options",
                        tint = Color(0xFF1C1B1B)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Hero Image & Room Identity
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    AsyncImage(
                        model = "https://lh3.googleusercontent.com/aida-public/AB6AXuBciLOWFL5ZYR_89o0WU85NqPe75G6DBnAkC4kbU5qxsTHILVOjaejxSKBSkRvhnRij1NfizdFntL94sRpJ8v-4iPHgaYDNCWn4BHRH1IhEY-rdMb2Y8vmLjKrqgSyg-ZGSHuvRfYxlRS3BvieUgqPcPnthZkx0dzauIQmIrntrrSBXZguW0y_dXV96p-4NJCynjnKIn7CDX9EtxOfN9ubvGxeazNsa5pPrTjvM81adJZU2qvR8R8sl-a0dbi3MFzdZPG_UPWy6Aw",
                        contentDescription = "Room Cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f))
                    )
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Street Photography",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                color = Color(0xFF1C1B1B)
                            )
                            Text(
                                text = "14.2k members • 82 active",
                                fontSize = 12.sp,
                                color = FrameTextMuted
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { viewModel.toggleJoinRoom("room_street") },
                                shape = RoundedCornerShape(20.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("room_joined_toggle")
                            ) {
                                Text(
                                    text = "Joined",
                                    fontSize = 12.sp,
                                    color = Color(0xFF1C1B1B)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {},
                                modifier = Modifier
                                    .size(36.dp)
                                    .border(1.dp, FrameBorder, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PersonAdd,
                                    contentDescription = "Invite to Room",
                                    tint = Color(0xFF1C1B1B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Chasing fleeting moments, urban geometry, and shadows across global streets. Strictly original 35mm & digital work.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = FrameTextSecondary
                    )
                }
            }

            // Active Challenge Card in Room
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { viewModel.navigateTo(ScreenDestination.CHALLENGE_DETAIL) }
                        .testTag("room_active_challenge_card"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuB5huA2pqOXel7xI6NryDlWuaWtwN72z2-nhAwrsT_hViifgCSbAhn5gJotGG9WNI6pr0_NR4CVCOA7mMEWvSszzQeScOVNq1dqOlOdFmhht-BYev9M61wg_S4gemnOeobrsKPpcO3bACE0n77GeKxUQKKZSoOJcOJIJMZwfEREGlIAETwNpAlq3w4ilmadA2HiGmLSI6dfYSU_ro8EkKa3wlklcKMOMGlpLO6jlWT8cqabSrDSye7zSEvhNwzw3Wp_KSDrmSwnRw",
                            contentDescription = "Challenge thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ACTIVE CHALLENGE",
                                color = FramePrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Your city after dark",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1C1B1B)
                            )
                            Text(
                                text = "4 days left • 342 joined",
                                fontSize = 11.sp,
                                color = FrameTextMuted
                            )
                        }

                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.CHALLENGE_DETAIL) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1B)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("View", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }

            // Room Segmented Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFFCF9F8),
                    contentColor = FramePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = FramePrimary
                        )
                    },
                    modifier = Modifier.padding(top = 10.dp)
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { viewModel.setRoomDetailTab(0) },
                        text = {
                            Text(
                                "Feed",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { viewModel.setRoomDetailTab(1) },
                        text = {
                            Text(
                                "Challenges",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { viewModel.setRoomDetailTab(2) },
                        text = {
                            Text(
                                "Stories",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 2) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                }
            }

            // Posts in this room
            items(streetPosts.size) { index ->
                val post = streetPosts[index]
                FeedPostCard(
                    post = post,
                    onPostClick = { viewModel.navigateTo(ScreenDestination.POST_PROCESS) },
                    onRoomClick = {},
                    onLikeClick = { viewModel.toggleLike(post.id) },
                    onBookmarkClick = { viewModel.toggleBookmark(post.id) }
                )
            }
        }
    }
}
