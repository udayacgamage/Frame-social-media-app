package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FramePrimary = Color(0xFFB12417)
val FrameOnPrimary = Color(0xFFFFFFFF)
val FramePrimaryContainer = Color(0xFFD43E2D)
val FrameOnPrimaryContainer = Color(0xFFFFFBFF)

val FrameSecondary = Color(0xFF5E5E5E)
val FrameOnSecondary = Color(0xFFFFFFFF)
val FrameSecondaryContainer = Color(0xFFE1DFDF)
val FrameOnSecondaryContainer = Color(0xFF626262)

val FrameTertiary = Color(0xFF006577)
val FrameOnTertiary = Color(0xFFFFFFFF)
val FrameTertiaryContainer = Color(0xFF008096)
val FrameOnTertiaryContainer = Color(0xFFF9FDFF)

val FrameSurface = Color(0xFFFCF9F8)
val FrameOnSurface = Color(0xFF1C1B1B)
val FrameSurfaceVariant = Color(0xFFE5E2E1)
val FrameOnSurfaceVariant = Color(0xFF5A403C)

val FrameSurfaceContainerLowest = Color(0xFFFFFFFF)
val FrameSurfaceContainerLow = Color(0xFFF6F3F2)
val FrameSurfaceContainer = Color(0xFFF0EDEC)
val FrameSurfaceContainerHigh = Color(0xFFEBE7E7)
val FrameSurfaceContainerHighest = Color(0xFFE5E2E1)
val FrameSurfaceDim = Color(0xFFDCD9D9)

val FrameOutline = Color(0xFF8E706B)
val FrameOutlineVariant = Color(0xFFE3BEB8)
val FrameBorder = Color(0xFFEAEAEA)
val FrameTextSecondary = Color(0xFF666666)
val FrameTextMuted = Color(0xFF999999)
