package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.PostEntity
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

data class StoryItem(
    val id: String,
    val title: String,
    val avatarUrl: String,
    val isUserStory: Boolean = false,
    val isLiveCollaborative: Boolean = false
)

@Composable
fun HomeScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val posts by viewModel.posts.collectAsState()

    val stories = listOf(
        StoryItem(
            id = "story_user",
            title = "Your Story",
            avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuC0Qz1GLJbhEpQ9Mz-HsmeIErScUdwGu3GG89M3A5Gw0lceDLNiMNppnLRem5c6cfpdKoGoD_RfA124nIZT_pEjsDKpi2gysANDOnMZfcc-2SIkFJp196jpjewwROND_bGyK-XRcwAkKSMM0mXXjQNKY2KQJCOm7-l_tJqo0bAosjUxXvGPyiR-MC7aJUu27RKwPLby9VcVlBqp5C-vjOLUrnm3TiGqebB1BdVhbl_7tcvsDBb8rnnE_NKNPEO8NTe7dj6C1ro-qw",
            isUserStory = true
        ),
        StoryItem(
            id = "story_ella",
            title = "Weekend in Ella",
            avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuC4rv1v-fOKpc5HWu_sGckuzoQJo489M9Gk7oRG8ZhCfO8G8CKf5xIpOQnlfJY2hMbW1dYMquuM7Qai7SKTlafLw-G3iiI6MjhR7Ng1AUQZ62QVgSUhT7ZBTMpeNGvqEZ7s5OSdURunThiWDyHeDf9_EFGviZvOd282VlUEdfRqCofiYMJfjigfYoLZPNPVh-z_H4oSNfntmLKzKKApvo94DTU6BeAzPxg4R4lteyKOE-sX1ViGdLLv6gi-BwDsYRfelIlzCUfm1w",
            isLiveCollaborative = true
        ),
        StoryItem(
            id = "story_pottery",
            title = "Nordic Pottery",
            avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCMPgCDBQq3pP82BnHev0Vbx39riw0Dvp9ZG93Ql0B354lspPlD2vzqF7vkhtJQRukjc9Ntypz44QsRdN__7_3qOfZEkIztSF2tqxPqE_la9vh1fxHj5qGPYTbQTCIoPKLYhnm2_ws4KO_7nqjVn043H2KAYbEF1cPRX2vzAm3OBV9FVGeJ4yjVHfgJV5HLtUHELvb3QjpcA0ZiO8NLCv8mSfAabXgvkgPFpqdTUspq-kXkZyFpMSsBne_VrlrAQ7N1M9VmWFThpw"
        ),
        StoryItem(
            id = "story_tokyo",
            title = "Tokyo Nights",
            avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBNlLPGxPQ24wQmDnEdXmntTUYvazyKvO3YfEQ0WYw8be89Dxzy0mmiyH1aq97ZM7OE-F21v3CXhQD1WkpDgYJv5oebg6pYKKZd3U-G4swhWxJITyRrIBUEQQtq9PlnIv48BrqYf8hzvR1MxZzYWN7_w6-cB1thZdmhacmB_tNBlc5SRFcLxUnPS7bpM8W3c18ItoB0NnOHFWYNWPQXGIKyOyA0_H8RLdhHJVMkfljvwQQjO4eINz75J0gbcoTh_Ye8V43QqqtgSw"
        ),
        StoryItem(
            id = "story_film",
            title = "Film Journal",
            avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuB6sypg6hqpVBI9wBzUlpjipgPWJw5xNnA2726mgggl1KsL72S-B6Kj0zXlCCPCvHPkJZxw2m66kP3m8oOVOeZ_Wn0ptUdQr-69jXHuJ8W_MHxgT2gFSKRWcIV43WO8FQOz6LD-G8nGGabwkABYnIpnz_W-VytnHSzVp5ET34oas4zBT13HrFag9qaDRc6YTBr7BrdH-3Qxvhw2yiI1MfqArtoH9bAUimfoeXqioKcWUdHOChwIbr0t6WhJ0_7sGTK4iup6qTFyIw"
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "F R A M E",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                letterSpacing = 2.sp,
                color = Color(0xFF1C1B1B)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.ACTIVITY) },
                    modifier = Modifier.testTag("home_messages_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Send,
                        contentDescription = "Messages",
                        tint = Color(0xFF1C1B1B),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.ACTIVITY) },
                        modifier = Modifier.testTag("home_notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Activity Notifications",
                            tint = Color(0xFF1C1B1B),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    // Unread badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 8.dp, end = 8.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(FramePrimary)
                    )
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Stories Rail
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(stories) { story ->
                        StoryAvatar(
                            story = story,
                            onClick = {
                                if (story.id == "story_ella") {
                                    viewModel.navigateTo(ScreenDestination.SHARED_STORY)
                                } else if (story.isUserStory) {
                                    viewModel.navigateTo(ScreenDestination.NEW_CREATION)
                                }
                            }
                        )
                    }
                }
                HorizontalDivider(color = FrameBorder, thickness = 1.dp)
            }

            // Feed Items
            items(posts) { post ->
                FeedPostCard(
                    post = post,
                    onPostClick = {
                        viewModel.navigateTo(ScreenDestination.POST_PROCESS)
                    },
                    onRoomClick = {
                        viewModel.navigateTo(ScreenDestination.ROOM_DETAIL)
                    },
                    onLikeClick = {
                        viewModel.toggleLike(post.id)
                    },
                    onBookmarkClick = {
                        viewModel.toggleBookmark(post.id)
                    }
                )
            }

            // Draft in progress banner
            item {
                DraftProgressCard(
                    onDraftClick = {
                        viewModel.navigateTo(ScreenDestination.NEW_CREATION)
                    }
                )
            }

            // "You're caught up" message
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Caught up",
                        tint = FramePrimary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "You're all caught up",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1C1B1B)
                    )
                    Text(
                        text = "You've seen all new shared work from your rooms.",
                        fontSize = 13.sp,
                        color = FrameTextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.NEW_CREATION) },
                        colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("caught_up_create_button")
                    ) {
                        Text("Start a creation", color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StoryAvatar(
    story: StoryItem,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag("story_${story.id}")
    ) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            val ringBorder = if (story.isLiveCollaborative) {
                Modifier.border(2.dp, FramePrimary, CircleShape)
            } else if (story.isUserStory) {
                Modifier.border(1.5.dp, FrameBorder, CircleShape)
            } else {
                Modifier.border(1.5.dp, Color(0xFF999999), CircleShape)
            }

            AsyncImage(
                model = story.avatarUrl,
                contentDescription = story.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .then(ringBorder)
            )

            if (story.isUserStory) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(FramePrimary)
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Story",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = story.title,
            fontSize = 11.sp,
            color = Color(0xFF1C1B1B),
            maxLines = 1,
            fontWeight = if (story.isLiveCollaborative) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun FeedPostCard(
    post: PostEntity,
    onPostClick: () -> Unit,
    onRoomClick: () -> Unit,
    onLikeClick: () -> Unit,
    onBookmarkClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        // Author & Room Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = post.authorAvatarUrl,
                    contentDescription = post.authorName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = post.authorName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1C1B1B)
                        )
                        if (post.coAuthorName != null) {
                            Text(
                                text = " & ${post.coAuthorName}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1C1B1B)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.clickable(onClick = onRoomClick),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "in ",
                            fontSize = 11.sp,
                            color = FrameTextMuted
                        )
                        Text(
                            text = post.roomName,
                            fontSize = 11.sp,
                            color = FramePrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Text(
                text = post.timestamp,
                fontSize = 11.sp,
                color = FrameTextMuted
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Post Image
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onPostClick)
        ) {
            AsyncImage(
                model = post.photoUrl,
                contentDescription = post.caption,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 5f)
                    .background(Color(0xFFE5E2E1))
            )

            // Process stages badge if available
            if (post.processStagesCount != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.65f))
                        .clickable(onClick = onPostClick)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = "Process",
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${post.processStagesCount} Process Stages",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Action Buttons Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Like Button
                IconButton(
                    onClick = onLikeClick,
                    modifier = Modifier.testTag("like_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (post.isLiked) FramePrimary else Color(0xFF1C1B1B),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Text(
                    text = "${post.likesCount}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1C1B1B)
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Comment Button
                IconButton(
                    onClick = onPostClick,
                    modifier = Modifier.testTag("comment_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = Color(0xFF1C1B1B),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = "${post.commentsCount}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1C1B1B)
                )
            }

            // Bookmark Button
            IconButton(
                onClick = onBookmarkClick,
                modifier = Modifier.testTag("bookmark_button_${post.id}")
            ) {
                Icon(
                    imageVector = if (post.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = if (post.isBookmarked) FramePrimary else Color(0xFF1C1B1B),
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Caption & Tags
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = post.caption,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                color = Color(0xFF1C1B1B)
            )

            if (post.techSpecs != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = post.techSpecs,
                    fontSize = 11.sp,
                    color = FrameTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = FrameBorder, thickness = 0.8.dp)
    }
}

@Composable
fun DraftProgressCard(
    onDraftClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable(onClick = onDraftClick)
            .testTag("draft_progress_card"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF6F3F2)),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Continue draft in Street Photography",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1B1B)
                )
                Text(
                    text = "Resume",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = FramePrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { 0.66f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = FramePrimary,
                trackColor = Color(0xFFE1DFDF)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "66% complete • 2 of 3 stages documented",
                fontSize = 11.sp,
                color = FrameTextMuted
            )
        }
    }
}
