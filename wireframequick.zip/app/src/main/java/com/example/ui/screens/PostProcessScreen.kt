package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CommentItem
import com.example.ui.components.PhotoComparisonSlider
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel

@Composable
fun PostProcessScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val sliderPos by viewModel.sliderPosition.collectAsState()
    val commentInput by viewModel.commentInput.collectAsState()

    val comments = remember {
        mutableStateListOf(
            CommentItem(
                authorName = "Marcus Ray",
                timestamp = "4h ago",
                content = "How did you manage the highlight clipping on the top column without muddying the shadows?",
                replyCount = "Elena Vance replied: A subtle S-curve with the black point pulled up slightly, plus a radial mask on the concrete pillar."
            ),
            CommentItem(
                authorName = "Chloe Lens",
                timestamp = "2h ago",
                content = "The warmth in the shadows really grounds the brutalist angles. Beautiful work!",
                replyCount = null
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("post_process_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF1C1B1B)
                )
            }

            Text(
                text = "Process Breakdown",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            Row {
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save Recipe",
                        tint = Color(0xFF1C1B1B)
                    )
                }
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = Color(0xFF1C1B1B)
                    )
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Author row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuBoHxbAxMax8M47qEMnZLNNH-T8OpkT0zVA471vkqcOiF5SjfBSnDslwBOZCGs2WCrIEX9IFIlpB0aHGnS-tBDQSNx6uWIiHPQCkFCBeVLzCP2dzJUEsgl5nU2Gt-MPF4otdr6Y_XSiaCteFyKplCwJxcRANd9f-d-iSww_j3HABJjNkA5m1UsXpVtvRrS2oCQ2qswMp_Dvbv3h1EfzWJBmfxzIi5IoyHmT6ofW69hkx822gTLfsmxc7Cqzp6aIvCBm8ruhxsM7JQ",
                            contentDescription = "Author Avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Elena Vance",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1C1B1B)
                            )
                            Text(
                                text = "in Street Photography Room",
                                fontSize = 11.sp,
                                color = FramePrimary
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Follow", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                    }
                }

                // Title
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = "Dappled Brutalism: Exposing for Highlights",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = Color(0xFF1C1B1B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Interactive Before & After Slider
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    PhotoComparisonSlider(
                        rawUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDr3guoVmV99k1a30wsI4AMDT6EHEIkBnZrKBzbG7_9dQFxHj4UPnti9PhFB3ar-zGp-L69FPvKyNwkQb-mvfQLN9o2oZy99HDtHOluuriG4hGiJ0zlWTD6w-0Pkh4GVHOYjgvbwq_ZgUHugdXiejN5t0MZR9UrIbfTfUYhF4vHDzBr5okeuci4hvNOlzC_AE21fly4_lbl8aogKIe_3_T2JvQ2tp5yCSeMrGsv4WhP5ld10g_FUUb67jwlpB2ryVCU-C6L_h9VbA",
                        finalUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAJCd9W8asKFGdlU462f97KLir0O9_qKaScStYmPSO8PgdsVz_g1TDiTb14p26BTVAPHv3gf_KFHGUgbQbHo7Hp7iR0TY_f1EmL51HR1aHzp68cYA6nzobXhwWmvOl34IG7UU0gwAR6RKfudm7ljIq2ctItZLW9dzd1Agpv3PZbABFJuenK8KxC-eAGmjrbFygDhraMXd5Dcg9HZVMaDyh7eTHR6GdS4ZaB_PzgW-KI7PjiFOQ1KJy8jbmTlDFmy1AGxkLUsXh9mw",
                        splitPosition = sliderPos,
                        onSplitPositionChanged = { viewModel.setSliderPosition(it) },
                        height = 360.dp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Save",
                            modifier = Modifier.size(14.dp),
                            tint = Color(0xFF1C1B1B)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save Recipe", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                    }

                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.HelpOutline,
                            contentDescription = "Ask",
                            modifier = Modifier.size(14.dp),
                            tint = Color(0xFF1C1B1B)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ask Question (12)", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                    }

                    Button(
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CameraAlt,
                            contentDescription = "Try",
                            modifier = Modifier.size(14.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Try This (8)", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = FrameBorder, thickness = 1.dp)
            }

            // 3 Process Stages
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DOCUMENTED PROCESS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FrameTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 1
                    ProcessStageCard(
                        stepNum = "01",
                        category = "In-Camera",
                        title = "Gear & Setup",
                        description = "Exposed strictly for the harsh light sliver hitting the raw concrete column. Leica Q2 at f/5.6 gave edge-to-edge sharpness while keeping depth.",
                        extraCardContent = {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF6F3F2)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) {
                                Text(
                                    text = "Leica Q2 • 28mm Summilux at f/5.6 • ISO 200 • 1/500s • -1.0 EV",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF1C1B1B),
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 2
                    ProcessStageCard(
                        stepNum = "02",
                        category = "Environment",
                        title = "Light Observation",
                        description = "Wait for the 16:42 raking light angle. The window geometry casts a 34° diagonal shadow across the floor.",
                        extraCardContent = {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFFEBE7E7))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("☀️ 16:42 Golden Hour", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFFEBE7E7))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("📐 34° Azimuth", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 3
                    ProcessStageCard(
                        stepNum = "03",
                        category = "Lightroom",
                        title = "Color & Tonal Crafting",
                        description = "Lifted deep shadows by +15, warmed midtones, pulled highlights down -8 to recover concrete texture, added subtle film grain (Amount: 12, Size: 25).",
                        extraCardContent = {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2C2523))
                                )
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF8A827E))
                                )
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFC7B198))
                                )
                            }
                        }
                    )
                }

                HorizontalDivider(color = FrameBorder, thickness = 1.dp)
            }

            // Q&A Thread Header
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "COMMUNITY Q&A (${comments.size + 10})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FrameTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    comments.forEach { comment ->
                        CommentCard(comment = comment)
                        Spacer(modifier = Modifier.height(14.dp))
                    }
                }
            }
        }

        // Bottom Comment Input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .imePadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commentInput,
                onValueChange = { viewModel.setCommentInput(it) },
                placeholder = { Text("Ask a question about this process...", fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("process_comment_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FramePrimary,
                    unfocusedBorderColor = FrameBorder
                ),
                shape = RoundedCornerShape(20.dp),
                maxLines = 2
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (commentInput.isNotBlank()) {
                        comments.add(
                            CommentItem(
                                authorName = "You (@elena_v)",
                                timestamp = "Just now",
                                content = commentInput.trim(),
                                replyCount = null
                            )
                        )
                        viewModel.setCommentInput("")
                    }
                },
                modifier = Modifier.testTag("process_comment_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = FramePrimary
                )
            }
        }
    }
}

@Composable
fun ProcessStageCard(
    stepNum: String,
    category: String,
    title: String,
    description: String,
    extraCardContent: @Composable () -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = stepNum,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = FramePrimary,
            modifier = Modifier.width(36.dp)
        )

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = category.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = FrameTextMuted,
                    letterSpacing = 1.sp
                )
                Text(
                    text = " • $title",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1B1B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = FrameTextSecondary
            )

            extraCardContent()
        }
    }
}

@Composable
fun CommentCard(comment: CommentItem) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF6F3F2))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = comment.authorName,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )
            Text(
                text = comment.timestamp,
                fontSize = 10.sp,
                color = FrameTextMuted
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = comment.content,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            color = Color(0xFF1C1B1B)
        )

        if (comment.replyCount != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White)
                    .padding(8.dp)
            ) {
                Text(
                    text = comment.replyCount,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = FrameTextSecondary
                )
            }
        }
    }
}
