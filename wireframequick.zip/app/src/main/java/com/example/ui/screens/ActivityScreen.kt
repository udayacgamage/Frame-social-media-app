package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun ActivityScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.activityTab.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("activity_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF1C1B1B)
                )
            }

            Text(
                text = "Activity & Inbox",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            Box(modifier = Modifier.size(48.dp))
        }

        // Segmented Tab
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFFEBE7E7))
                .padding(3.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (selectedTab == 0) Color.White else Color.Transparent)
                    .clickable { viewModel.setActivityTab(0) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Activity",
                    fontSize = 12.sp,
                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                    color = if (selectedTab == 0) Color(0xFF1C1B1B) else FrameTextMuted
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (selectedTab == 1) Color.White else Color.Transparent)
                    .clickable { viewModel.setActivityTab(1) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Messages",
                        fontSize = 12.sp,
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedTab == 1) Color(0xFF1C1B1B) else FrameTextMuted
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(FramePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("3", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Collaboration Invitation Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(ScreenDestination.SHARED_STORY) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = "https://lh3.googleusercontent.com/aida-public/AB6AXuBtFr2F16t8bmDA9IeR9gQFk2DQexgKYgMZUQ9e4U3wR7zPy9px_CKKHKUAQ9XIVYldFHt0-TXIyNIxH37ArgJWwNSjJG9jK_xFUliNXqxtyHtOKKQyLuITA2_CES8ViAByJqdLrN6g6UxfgtpS8uE52IP4_5z7i4Q1OqgheILHadBLsBtY53-RKUYAakcq8QYfLgQYR5sdomBsYe7Tc_zSRXKdkBEviIfKMO2XOb8eC4Jik2kE8gzeWSWWOEksbPq5dhKv9YXOCA",
                                    contentDescription = "Chloe",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "COLLABORATION INVITATION",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FramePrimary,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "Chloe Lens invited you to collaborate on 'A Weekend in Ella'",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1C1B1B)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {},
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Decline", fontSize = 12.sp, color = FrameTextMuted)
                                }

                                Button(
                                    onClick = { viewModel.navigateTo(ScreenDestination.SHARED_STORY) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.weight(1.5f)
                                ) {
                                    Text("Accept & View", fontSize = 12.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }

                // Section header
                item {
                    Text(
                        text = "EARLIER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FrameTextMuted,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                // Notification items
                item {
                    NotificationRow(
                        avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuA49YMLIh19DCj4wO1kGwCklnBGe9B12uzGMQ915jZrlWL4fPe8ftskHRTmdNLWf8hrR8f8uTqa6J8G3OxgJhk1pkUdHpONlD4guQYLwHQt20epQ1yULJlmTeToIpJoUPNHH3bfexSGI35-pIiJEYS-zg9i8XmqfwECojhHSFboOk-w3FumsAfC78xvA3Lk38C1Jml_CK9tynICNcSPcxN8l_6JwvQSTUQMRjDcBHT09cu_f_ewFlGqFCvE866h-5bNUZAnRhOuRA",
                        title = "Kenji Sato commented on your process:",
                        content = "\"The exposure compensation tip saved my highlights on the neon street sign!\"",
                        time = "3h ago",
                        thumbUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDEWYuWwVK9EtI5xeLcS5Lq5IMsztenCByB-nr4e7K8lISM4GjREWbVFHlanx2EUjvOWHaFvI0hj0BQTt_NIr9cUL9RPCDslOAjXPZYjAnnTcklEf4aNJwc9pAfvlVbPkJclc3fRH68f1CHqoxX4-7ajAaWL3qfL4avhTGGXrItos_RKQFjB8-vdmkJXFtAaB4JG11W8ikoY4O3EQXzYbgAOyRCllBhpvxKpzZblidwe8A97gALUy6PamkSk27KogirbB_fKmEF7Q",
                        onClick = { viewModel.navigateTo(ScreenDestination.POST_PROCESS) }
                    )
                }

                item {
                    NotificationRow(
                        avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDWF1w1KUJYyd3CY9Qfk9J1Y5Yv527o86l99MxoREiZfo57XAT0B4rQT9wTDyn_MoIcuvO1YXZfur4C2rpnjuWR7B8-w3_60CrGHF_DfnqLUdwv8GQLIRd_oSbxysQndU4MYSCZxlLuatZGAzTYeLKbJsSp6-hQ41-mAA23XIkbTmprQm6yLz79YPL5UoyK5VyZUWjnPTeKrPCYyHT4NICK381i-6JAW0oqSSe5mbI51C3nu44ApRALpZfil4iJe4cOJf0uxuvF6w",
                        title = "Mateo Reyes and 14 others liked your RAW exposure breakdown in Street Photography",
                        content = null,
                        time = "6h ago",
                        thumbUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDfMXZN5K8KYeoVRbDV3Hu7P38p8WL-HOHK7Y_5IDWZvBtpoE8KykwA7zjicn_HnYfejV8e-DvkRCyBhMjhMaFXg7UJSZGO7l7p52YtICARc-K5RigqNNSKsxDRx0zrTW9oaG9WEOXsV9Y6AJc_xglFpHnV6_TFJSAS44pEL5IiTr53YzU-OW-V4oyV5cG7AK9reuWLwQ5ZwMwATkjEnMDs6isrJZowryoE8-Y1K1cvG-G5ZVUFgwalcEIsy9-hTnakKsotbGOOmg",
                        onClick = { viewModel.navigateTo(ScreenDestination.POST_PROCESS) }
                    )
                }
            }
        } else {
            // Messages Tab
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    MessageRow(
                        avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAc0-_M3O9p3EQngJh-QPjr7gItUqrBEEiwNcHkEK538jkLZQPj4Ao-W6ggorKNuFXJhXVLBbIkCm7z8JZQv89apMELI5h-oQmg7OX8cJQ97XZjxFIAWC1s43a6YzHX1ynzOOSAv_wdbR1f6GpzrzBItheUkj8HXy5ajBG89Jf-xD2UeSFEn39vR1d1xzZpYfmh4d194R4vBxwM2qsXczymw443pygBDiRpc0anXsdMMM2yr-nngIaSYo_pEJ8hfmMExmBhkJWUvQ",
                        name = "Chloe Lens",
                        preview = "Hey! Did you check out the morning shots at Nine Arch?",
                        time = "10m ago",
                        unread = true,
                        onClick = { viewModel.navigateTo(ScreenDestination.SHARED_STORY) }
                    )
                }

                item {
                    MessageRow(
                        avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuB22aVdnEFpmuHdn1iI2MeuXcB_puv8Hh_AFzBRm4M0mIUo5g_oKfibjqgj1nkcrPbkdCLufPTLVzDigfB63Y72_PKl_qYtQeXdDx124GP8-MaRhnNFF8b4hbhl5df6e2Zs1bavEhcmgRM6aBkq6lsMrILHWENKgHsF01O5I4YNUnLJvDvxPoLEBOTIK35Wmt2UBldB7mDJ9n2n8iqpb80SXOgqHiGdCaOD3D2v5PWNyxVl4MtnnPYAZ14AaeafYecrQGIRpwoPsg",
                        name = "Marcus Ray",
                        preview = "Love the contrast curve on that brutalist column.",
                        time = "2h ago",
                        unread = false,
                        onClick = { viewModel.navigateTo(ScreenDestination.POST_PROCESS) }
                    )
                }

                item {
                    MessageRow(
                        avatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBciLOWFL5ZYR_89o0WU85NqPe75G6DBnAkC4kbU5qxsTHILVOjaejxSKBSkRvhnRij1NfizdFntL94sRpJ8v-4iPHgaYDNCWn4BHRH1IhEY-rdMb2Y8vmLjKrqgSyg-ZGSHuvRfYxlRS3BvieUgqPcPnthZkx0dzauIQmIrntrrSBXZguW0y_dXV96p-4NJCynjnKIn7CDX9EtxOfN9ubvGxeazNsa5pPrTjvM81adJZU2qvR8R8sl-a0dbi3MFzdZPG_UPWy6Aw",
                        name = "Street Photography Curators",
                        preview = "Your submission 'Rain on wet asphalt' was selected for the weekly spotlight.",
                        time = "1d ago",
                        unread = false,
                        onClick = { viewModel.navigateTo(ScreenDestination.CHALLENGE_DETAIL) }
                    )
                }
            }
        }
    }
}

@Composable
fun NotificationRow(
    avatarUrl: String,
    title: String,
    content: String?,
    time: String,
    thumbUrl: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = "Avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1C1B1B)
            )
            if (content != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = content,
                    fontSize = 11.sp,
                    color = FrameTextSecondary,
                    maxLines = 2
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = time,
                fontSize = 10.sp,
                color = FrameTextMuted
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        AsyncImage(
            model = thumbUrl,
            contentDescription = "Thumbnail",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(6.dp))
        )
    }
}

@Composable
fun MessageRow(
    avatarUrl: String,
    name: String,
    preview: String,
    time: String,
    unread: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = name,
                    fontSize = 13.sp,
                    fontWeight = if (unread) FontWeight.Bold else FontWeight.SemiBold,
                    color = Color(0xFF1C1B1B)
                )
                Text(
                    text = time,
                    fontSize = 10.sp,
                    color = if (unread) FramePrimary else FrameTextMuted
                )
            }

            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = preview,
                fontSize = 12.sp,
                color = if (unread) Color(0xFF1C1B1B) else FrameTextSecondary,
                fontWeight = if (unread) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1
            )
        }

        if (unread) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(FramePrimary)
            )
        }
    }
}
