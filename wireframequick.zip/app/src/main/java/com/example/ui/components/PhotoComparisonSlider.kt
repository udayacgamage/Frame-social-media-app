package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun PhotoComparisonSlider(
    rawUrl: String,
    finalUrl: String,
    splitPosition: Float,
    onSplitPositionChanged: (Float) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 380.dp
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black)
            .testTag("photo_comparison_slider")
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        val splitX = widthPx * splitPosition

        // 1. Bottom layer: Final Image
        AsyncImage(
            model = finalUrl,
            contentDescription = "Final Edit",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top layer: RAW image clipped to the left side
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CustomLeftClipShape(splitPosition))
        ) {
            AsyncImage(
                model = rawUrl,
                contentDescription = "RAW Capture",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // 3. Badges (RAW on left, FINAL on right)
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "RAW",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .background(Color(0xFFB12417).copy(alpha = 0.9f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "FINAL",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // 4. Vertical Divider Line & Drag Handle
        Box(
            modifier = Modifier
                .offset(x = maxWidth * splitPosition - 1.dp)
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.White)
        )

        // Centered draggable thumb
        Box(
            modifier = Modifier
                .offset(x = maxWidth * splitPosition - 18.dp, y = maxHeight / 2 - 18.dp)
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.White)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val newSplit = (splitPosition + dragAmount.x / widthPx).coerceIn(0.05f, 0.95f)
                        onSplitPositionChanged(newSplit)
                    }
                }
                .testTag("slider_handle"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SwapHoriz,
                contentDescription = "Drag comparison",
                tint = Color(0xFF1C1B1B),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

private class CustomLeftClipShape(private val fraction: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path().apply {
            reset()
            val clipWidth = size.width * fraction
            addRect(Rect(0f, 0f, clipWidth, size.height))
            close()
        }
        return Outline.Generic(path)
    }
}
