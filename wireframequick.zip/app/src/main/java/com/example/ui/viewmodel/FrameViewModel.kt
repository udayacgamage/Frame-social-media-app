package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChallengeEntity
import com.example.data.model.PostEntity
import com.example.data.model.RoomEntity
import com.example.data.model.StoryMomentEntity
import com.example.data.repository.FrameRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NavigationTab {
    HOME,
    ROOMS,
    CREATE,
    CHALLENGES,
    YOU
}

enum class ScreenDestination {
    HOME_FEED,
    ROOMS_DISCOVER,
    ROOM_DETAIL,
    CHALLENGES_HUB,
    CHALLENGE_DETAIL,
    SHARED_STORY,
    POST_PROCESS,
    NEW_CREATION,
    ACTIVITY,
    PROFILE
}

class FrameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = FrameRepository(application)

    val posts: StateFlow<List<PostEntity>> = repository.allPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rooms: StateFlow<List<RoomEntity>> = repository.allRooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val challenges: StateFlow<List<ChallengeEntity>> = repository.allChallenges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storyMoments: StateFlow<List<StoryMomentEntity>> = repository.getStoryMoments("ella_weekend")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _currentScreen = MutableStateFlow(ScreenDestination.HOME_FEED)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Backstack history for back navigation
    private val screenHistory = mutableListOf<ScreenDestination>()

    // Discover Rooms Filter
    private val _selectedRoomCategory = MutableStateFlow("All")
    val selectedRoomCategory: StateFlow<String> = _selectedRoomCategory.asStateFlow()

    // Challenges Hub Filter
    private val _selectedChallengeCategory = MutableStateFlow("All")
    val selectedChallengeCategory: StateFlow<String> = _selectedChallengeCategory.asStateFlow()

    // Room detail tab (0: Feed, 1: Challenges, 2: Stories)
    private val _roomDetailTab = MutableStateFlow(0)
    val roomDetailTab: StateFlow<Int> = _roomDetailTab.asStateFlow()

    // Activity tab (0: Activity, 1: Messages)
    private val _activityTab = MutableStateFlow(0)
    val activityTab: StateFlow<Int> = _activityTab.asStateFlow()

    // Profile tab (0: Creations, 1: Stories, 2: Saved)
    private val _profileTab = MutableStateFlow(0)
    val profileTab: StateFlow<Int> = _profileTab.asStateFlow()

    // Compare split slider (0f to 1f)
    private val _sliderPosition = MutableStateFlow(0.5f)
    val sliderPosition: StateFlow<Float> = _sliderPosition.asStateFlow()

    // New Creation State
    private val _creationMode = MutableStateFlow(0) // 0: Share a Moment, 1: Shared Story, 2: Challenge
    val creationMode: StateFlow<Int> = _creationMode.asStateFlow()

    private val _creationCaption = MutableStateFlow("Exploring wheel balance and raw earthy clay forms during the early morning studio study session.")
    val creationCaption: StateFlow<String> = _creationCaption.asStateFlow()

    private val _creationDestinationRoom = MutableStateFlow("Street Photography")
    val creationDestinationRoom: StateFlow<String> = _creationDestinationRoom.asStateFlow()

    private val _creationVisibility = MutableStateFlow("Public Room")
    val creationVisibility: StateFlow<String> = _creationVisibility.asStateFlow()

    private val _creationQuietMode = MutableStateFlow(true)
    val creationQuietMode: StateFlow<Boolean> = _creationQuietMode.asStateFlow()

    // Moment text input
    private val _momentInput = MutableStateFlow("")
    val momentInput: StateFlow<String> = _momentInput.asStateFlow()

    // Post & Process comment input
    private val _commentInput = MutableStateFlow("")
    val commentInput: StateFlow<String> = _commentInput.asStateFlow()

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
        when (tab) {
            NavigationTab.HOME -> navigateTo(ScreenDestination.HOME_FEED, clearHistory = true)
            NavigationTab.ROOMS -> navigateTo(ScreenDestination.ROOMS_DISCOVER, clearHistory = true)
            NavigationTab.CREATE -> navigateTo(ScreenDestination.NEW_CREATION, clearHistory = true)
            NavigationTab.CHALLENGES -> navigateTo(ScreenDestination.CHALLENGES_HUB, clearHistory = true)
            NavigationTab.YOU -> navigateTo(ScreenDestination.PROFILE, clearHistory = true)
        }
    }

    fun navigateTo(destination: ScreenDestination, clearHistory: Boolean = false) {
        if (clearHistory) {
            screenHistory.clear()
        } else {
            screenHistory.add(_currentScreen.value)
        }
        _currentScreen.value = destination

        // Update tab highlight accordingly
        when (destination) {
            ScreenDestination.HOME_FEED -> _currentTab.value = NavigationTab.HOME
            ScreenDestination.ROOMS_DISCOVER, ScreenDestination.ROOM_DETAIL -> _currentTab.value = NavigationTab.ROOMS
            ScreenDestination.NEW_CREATION -> _currentTab.value = NavigationTab.CREATE
            ScreenDestination.CHALLENGES_HUB, ScreenDestination.CHALLENGE_DETAIL -> _currentTab.value = NavigationTab.CHALLENGES
            ScreenDestination.PROFILE, ScreenDestination.ACTIVITY -> _currentTab.value = NavigationTab.YOU
            ScreenDestination.SHARED_STORY, ScreenDestination.POST_PROCESS -> {
                // Keep current tab or highlight Room
            }
        }
    }

    fun navigateBack(): Boolean {
        if (screenHistory.isNotEmpty()) {
            val prev = screenHistory.removeAt(screenHistory.size - 1)
            _currentScreen.value = prev
            return true
        } else if (_currentScreen.value != ScreenDestination.HOME_FEED) {
            selectTab(NavigationTab.HOME)
            return true
        }
        return false
    }

    fun setRoomCategory(cat: String) {
        _selectedRoomCategory.value = cat
    }

    fun setChallengeCategory(cat: String) {
        _selectedChallengeCategory.value = cat
    }

    fun setRoomDetailTab(tab: Int) {
        _roomDetailTab.value = tab
    }

    fun setActivityTab(tab: Int) {
        _activityTab.value = tab
    }

    fun setProfileTab(tab: Int) {
        _profileTab.value = tab
    }

    fun setSliderPosition(pos: Float) {
        _sliderPosition.value = pos.coerceIn(0.05f, 0.95f)
    }

    fun setCreationMode(mode: Int) {
        _creationMode.value = mode
    }

    fun setCreationCaption(caption: String) {
        _creationCaption.value = caption
    }

    fun setCreationDestinationRoom(room: String) {
        _creationDestinationRoom.value = room
    }

    fun setCreationVisibility(visibility: String) {
        _creationVisibility.value = visibility
    }

    fun setCreationQuietMode(enabled: Boolean) {
        _creationQuietMode.value = enabled
    }

    fun setMomentInput(text: String) {
        _momentInput.value = text
    }

    fun setCommentInput(text: String) {
        _commentInput.value = text
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            repository.toggleLike(postId)
        }
    }

    fun toggleBookmark(postId: String) {
        viewModelScope.launch {
            repository.toggleBookmark(postId)
        }
    }

    fun toggleJoinRoom(roomId: String) {
        viewModelScope.launch {
            repository.toggleJoinRoom(roomId)
        }
    }

    fun toggleJoinChallenge(challengeId: String) {
        viewModelScope.launch {
            repository.toggleJoinChallenge(challengeId)
        }
    }

    fun submitNewMoment() {
        val text = _momentInput.value.trim()
        if (text.isEmpty()) return
        viewModelScope.launch {
            repository.addStoryMoment(
                storyId = "ella_weekend",
                authorHandle = "@elena_v",
                caption = text,
                photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCzkGJ9XqdIpSNfV8yYpA6kTCJ0WMvhDcgxwYrHXFV1w2rzAVFy4VtKCbxxy_dMi_bqnZufJUbc2Rc3XB_cR-iWvF-zP0mGUDs0nqutozNpiV4xqf755lptQzrXt_wdCPmVstCcOPH0UyyPDCVaXQOtOcp1kwSK0ArhWe0kRkFo1tfqo7y-RkUCM707MWONyD1F4BXkUFUp4tOto65QZ8hee8DYTuPgE-25Dt1wOU3RiyB_6HD6ST-NBAOlpjKoFS-rT-6PD0ENWQ",
                location = "Ella Highlands"
            )
            _momentInput.value = ""
        }
    }

    fun publishCreation() {
        viewModelScope.launch {
            repository.createPost(
                caption = _creationCaption.value,
                roomName = _creationDestinationRoom.value,
                photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCgmbS-WDJ6-KlEG2kXug36EBXmITXn4QGCrd949WFqA1407pfC9fxm0KTRjHuaSJ2sYFIkdc4QZEMADZWa7o3DwKexwwQO7tvVetfEeZYye4cRcPQFItRIme2k0yBtoFsdEFyDljYYFvda-1rGNWrBctGq5Dv4CYn9r_wmS6L7JzAuKftSfiD4T-egwoHCOLMOule_guPkHTclrWGfRrEzwYPz5Sl67LnO11gEJ8j6KGWWIgqAbgTG7_MFpB7QgYxLTg-QBzD7PA"
            )
            selectTab(NavigationTab.HOME)
        }
    }
}
