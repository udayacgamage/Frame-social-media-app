package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChallengeEntity
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

data class PerspectiveItem(
    val author: String,
    val imageUrl: String,
    val room: String
)

@Composable
fun ChallengesScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val challenges by viewModel.challenges.collectAsState()
    val selectedCategory by viewModel.selectedChallengeCategory.collectAsState()

    val categories = listOf("All", "Photography", "Culinary", "Art", "Writing")

    val perspectives = listOf(
        PerspectiveItem(
            author = "@elena_v",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBhgruWp07dHbRx3v_Nl7a33Ag8-15q5beqk-W5fYL5J-uIIr0C4XJn0AQqqYrNbsLb8iKxIgjq_KUriUyG2_YNOydBO4A6zRxpbWcCyUVuoX-JjWU6K_Z76-weP8DVWo3Bf_uvrDT22n4qQ5mWRbfPDiV4X7gevWKU-5cVnKGZqlWxrQ6yPtamTBh2SBtpWwMLwfPCtq3b1ExZ6xlkAV5b4Do5AlJgroOssYHN7eT75m-zoFbMfm1MirLQi1kYpSd-XP0wy4V8gg",
            room = "Street"
        ),
        PerspectiveItem(
            author = "@marcus_cooks",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDUvxcFkorlBAqROXJnwLgYfTZIAmWuhDBDFcbiMWhYBbfNF6XJopVlwNc0s-7D7Rn3LEQZANlBjfZYiQlSx9ku89iRBgIuzkY0su84VqUWKTaKpn-E_ArIrLgE_8eh-cYgcAC0--YLLhI2MWRrZqFonxQy9_L1WJ3omd_esMRNJJXc9C-X5KOGsjw0PU6yBBi0Q8k-N5zEfrfu50hBWZVkCOoizvWWOhuf-UTYsjvc-NOVHO3vi0WkYAEHLMSYbFRZgcdTPK63lg",
            room = "Cooking"
        ),
        PerspectiveItem(
            author = "@charlotte.b",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuA-o99LOHsxW0NYjnW2fV54I3SAYI0MBS8DHGFwnNcGu-8fyTPFs37aPUARou1KVorMtG0rUgkkuU8XX_2Kyzmr0u6Nvs8XSZF62abl4kGL85lSwUfUnFNiTzh2TTQ7_9W665WyIgD2Ld3uZwV7v1uDooFtHHEeeD7haLlLPxnAqlJXSDFLwa6FHZwNiF1vjh580ND0GS-Hq6P__g9iAyD8gBzB1idorpXKSSs4kHCA09tAK26zKvdyFdTrDbcxrDtC44U3gB49Cw",
            room = "Street"
        ),
        PerspectiveItem(
            author = "@t_park",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBsPBPBelXaexpk9gVCWE2q-L7dsvO34Tr8qK52W9tcQc53NAoPa9bKMXtCxH0vH3PAku0Qg1KFkSCdD3A2q9Qxii-bojO1bc1E2InFmBiHi7hBrxAGFrMRXBgpen_-UPVDKn8aWgQczxhY5_IFKgOCBdMv20fgKsbUDM4cC7ssiGseZxodYU8YFcKDWjtAdnyoMWaFBbvl888M0adxOmjaUIW4-O-lMvUXFgaM3MrxdW_iEAmd9wYWe99mk_q-bsK0hrivqIfMeA",
            room = "Ceramics"
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Challenges",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = "Challenge Info",
                    tint = Color(0xFF1C1B1B),
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Category Filter Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFF1C1B1B) else Color(0xFFEBE7E7))
                        .clickable { viewModel.setChallengeCategory(cat) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("challenge_category_$cat")
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) Color.White else Color(0xFF1C1B1B),
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Challenges list
            items(challenges) { challenge ->
                ChallengeCard(
                    challenge = challenge,
                    onClick = {
                        viewModel.navigateTo(ScreenDestination.CHALLENGE_DETAIL)
                    },
                    onToggleJoin = {
                        viewModel.toggleJoinChallenge(challenge.id)
                    }
                )
            }

            // Perspectives Carousel
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "RECENT PERSPECTIVES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = FrameTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(perspectives) { p ->
                        Column(
                            modifier = Modifier
                                .width(120.dp)
                                .clickable { viewModel.navigateTo(ScreenDestination.CHALLENGE_DETAIL) }
                        ) {
                            AsyncImage(
                                model = p.imageUrl,
                                contentDescription = p.author,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = p.author,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1C1B1B)
                            )
                            Text(
                                text = p.room,
                                fontSize = 11.sp,
                                color = FrameTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChallengeCard(
    challenge: ChallengeEntity,
    onClick: () -> Unit,
    onToggleJoin: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("challenge_card_${challenge.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                AsyncImage(
                    model = challenge.coverUrl,
                    contentDescription = challenge.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Days remaining badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.Schedule,
                            contentDescription = "Days remaining",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${challenge.daysRemaining} days remaining",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = challenge.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1C1B1B)
                        )
                        Text(
                            text = "${challenge.roomName} • ${challenge.joinedCount} joined",
                            fontSize = 11.sp,
                            color = FrameTextMuted
                        )
                    }

                    if (challenge.isJoined) {
                        OutlinedButton(
                            onClick = onToggleJoin,
                            shape = RoundedCornerShape(18.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = "Joined",
                                fontSize = 12.sp,
                                color = Color(0xFF1C1B1B)
                            )
                        }
                    } else {
                        Button(
                            onClick = onToggleJoin,
                            colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = "Join",
                                fontSize = 12.sp,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = challenge.prompt,
                    fontSize = 12.sp,
                    color = FrameTextSecondary
                )
            }
        }
    }
}
