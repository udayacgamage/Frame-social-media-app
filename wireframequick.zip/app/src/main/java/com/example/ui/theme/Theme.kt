package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = FramePrimary,
    onPrimary = FrameOnPrimary,
    primaryContainer = FramePrimaryContainer,
    onPrimaryContainer = FrameOnPrimaryContainer,
    secondary = FrameSecondary,
    onSecondary = FrameOnSecondary,
    surface = Color(0xFF181818),
    onSurface = Color(0xFFF3F0EF),
    surfaceVariant = Color(0xFF2B2A2A),
    onSurfaceVariant = Color(0xFFDCD9D9),
    background = Color(0xFF121212),
    onBackground = Color(0xFFF3F0EF),
    outline = FrameOutline
)

private val LightColorScheme = lightColorScheme(
    primary = FramePrimary,
    onPrimary = FrameOnPrimary,
    primaryContainer = FramePrimaryContainer,
    onPrimaryContainer = FrameOnPrimaryContainer,
    secondary = FrameSecondary,
    onSecondary = FrameOnSecondary,
    secondaryContainer = FrameSecondaryContainer,
    onSecondaryContainer = FrameOnSecondaryContainer,
    tertiary = FrameTertiary,
    onTertiary = FrameOnTertiary,
    tertiaryContainer = FrameTertiaryContainer,
    onTertiaryContainer = FrameOnTertiaryContainer,
    surface = FrameSurface,
    onSurface = FrameOnSurface,
    surfaceVariant = FrameSurfaceVariant,
    onSurfaceVariant = FrameOnSurfaceVariant,
    background = FrameSurface,
    onBackground = FrameOnSurface,
    outline = FrameOutline,
    outlineVariant = FrameOutlineVariant
)

@Composable
fun FrameTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
    FrameTheme(content = content)
}
