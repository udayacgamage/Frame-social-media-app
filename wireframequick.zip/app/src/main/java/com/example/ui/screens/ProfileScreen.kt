package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.FrameBorder
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

data class ProfilePhoto(
    val id: String,
    val url: String,
    val hasProcessBadge: Boolean = false,
    val isStack: Boolean = false
)

@Composable
fun ProfileScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.profileTab.collectAsState()

    val photos = listOf(
        ProfilePhoto(
            id = "p1",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDvTTrllJSdhH59lhi1OH3jnO3utByZDzzPPLFb_3__JsOs68ETyYhAjJXOPG4PSVElnsVrWuqlHU1zI6FzGEU8C_ad0zCdZKCcjyAwEOEXbJ7vu2eP1USiT7Lh-YddxcwbQpfe9itbb3hcSb_vifoHkUjWud9Y1uciHR0G_HLHVySC7LM3zOVugmyhWcem2yGnrRgoSt9z6iYc8_vUE-wsxPj8PxuXK7YgQ_BaQGJphe5lnfgKd7keDvkW2Byg56q6EgEJC8DBEA",
            hasProcessBadge = true
        ),
        ProfilePhoto(
            id = "p2",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuAGBk8dtj76PmgHo0i92qewR7_9qFsO789tsMiHmUVB2j62w9z0QiT2cdRvoPnILGUk-_brET-aXFxfMKZ81JoMcA2FnivW6bxvXfaKF-eZhcZOi6f7s-gQ_ziOpMQumkeI_G68yZL32k_WnNAXbOHd628vEN6uy3A0DKT9vOjfMkFJUVrEQdDhuRqZNUpF7JoLHKpu-jC6pcEcx3EWGs8VKySLYq0tzcmPGm7TSOHSYJHc59SbIJPAC4m28dyFhnUjXAhSe7ctjw",
            isStack = true
        ),
        ProfilePhoto(
            id = "p3",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDWdA8lSmb7_JYkVrFlyNM3S_3XDHXmNrsQOOkiWn3j_MFB1L9ctArDwhES6CyMnKnqJnPlN7JGCdC7PJ4FafRMd7h9gAPN79QxKWRqniOxDvxLQPpSJKmK1mXouG0KUJGXhESvHazpCtWA-Tah1AfYIlgGySvdI4KViGGkyCqKQt-7QvZLVfmL7WgVQPusVI575_ROAmeNyKQSuqcAmS2hapIhQbHmr9sIkX2_DaZdR0ZdGHEZXmgdCYiej-jfWzBMrQddcs_l-Q"
        ),
        ProfilePhoto(
            id = "p4",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDbiAxmfmUnjc0fGnVK5QN7gT0cuxtLeYGrSrfqecvMD0j5R9vqvnX14dFTSbSEjz0VLIZ08URZ0keE16FQRSHSD2p5pX45XCKbvlVQJ6AnDDBlD44gsgfCOIvTMFsLFEhohbLyp2F1W0okedoxAS-A4IHSrzXCdL6tJxWnrPAYCREyaaZO3_6vg9APt8xA4NxZuKBl5sOvJGk1-E1IbmKTXHShv5aveDWUS2I-AeGGr5pDKYnlA1QoDtaZkg6E1Zih91KU0ZRKrg",
            hasProcessBadge = true
        ),
        ProfilePhoto(
            id = "p5",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuCgvDTLJ40Kxdgdf0d-3JOJPoZlPIL_I7scXRIkCC-WOoPkKn_WlRUzEGB8oRWqU6_xI-Zd-zEWhSF6VBKWf1XsUeDA3WMWfzLELzdS2oLgNrTXGmJuRNiaPEWD3hDekS-hgCY7F3xFgGCTp1_7cNPlGld7OauLkDNe-do-_FJ6IIe0Ew4yCJPbic52UUN9P-7qaKdKTXAafIDfPyQ7mrhal44dqh5S-oO_NlKiomc_KvnRBodckssf6X9HSIWhtyNyPXGnb4TIyQ"
        ),
        ProfilePhoto(
            id = "p6",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuCYGVSPumhcy_5nTFH1GXI7ApjXDlh5kS-9OOOmYfl5ng4B58G4NgQ_BvBdhNFTpuQb9i9G6e8xYm6-BeYB903sKmub0Gl8BMbqXmS01AJu7yXtEhJpsPszB5SPQ8Ju3wu2ZfbbWHnEMbkz1sEop_phJKPliiT5N13sXaBxgLcCDtqHAWG0-9ztFX1-5_7bLcHbBPF6ip_tDeWH87TDN1rsL_ifzEG3JEiFxMIp_Va4XA3LflgPffrBTiudAaLJqWPyzvDjrWznlw"
        ),
        ProfilePhoto(
            id = "p7",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuBf0T08c4cyW-dxFdJLV7GC_fQaXG5XSt7scUmYMDqI6ECJ47MjmX6752gwjCLnzwJAOLsArWMGUvfm46db3nWLWd0zTir3-_nGCbB45n965MWIS4oZwcRRLLhMZFtuZFafPSP3U0OjzZ-PkEuxro2KEM-YMBIM9oz63JsZzKfrJHQ0vRlekKdN6Df57scGylAlSGJjj55sgi1_4vOMr7R0MHu6Ol_19MgTw_VvUWaqzE0-Rv7JS3Y7bcspY6GxI-4tGIjrDKN9zQ",
            hasProcessBadge = true
        ),
        ProfilePhoto(
            id = "p8",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuA3hHmNmLiYjk37n8fIZY0barzKF6NiMCbDi7Mmr-uJwbtzvYsOxOZLNm5zbz571ztB0PQVV0SRIqCz69lmawWGPUQigwYoSn2Bj-qIcudT-R4EN79N5LdUBZahSlN8KDcQ424_HrHkudY5jkOUCSTEnjU5gHKne8OAYZsvdffLcdGjliO3w40RwknfDB2uaVwsD2lzbTq_WLfUC8B3H6PxF02Kz4upIlEVhjWI0n4yZ9NIAI34PavWcY1cqbeXQCcBRbCgN1J51w"
        ),
        ProfilePhoto(
            id = "p9",
            url = "https://lh3.googleusercontent.com/aida-public/AB6AXuBtbz_PuS-FtAV9fXWNGmNGOfOqEZThpVrkHWKIVjqSaLuUL8Zto6EJp7Xq1UIUEJefulzeZTQlZ13xhFbZOEg9rfeKl4bbIhsgwi_we5hSrQINUkuG2X1tctDe_ibJHQpu8X32MJ7MjelGrUQ0jA49HTyP8TG5bOB2Wf9w_xyHM7XVNiDVn-5tiHZOPnrlaJuW5ynzyq9xoXintF6-DDx522o1I8ukjWaTTxORO-9ERUh3I3CbJuPepM7kNrpXhTt9M58N3N4bhQ"
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable {}
            ) {
                Text(
                    text = "elena_v",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1B1B)
                )
                Icon(
                    imageVector = Icons.Default.ExpandMore,
                    contentDescription = "Switch profile",
                    tint = Color(0xFF1C1B1B),
                    modifier = Modifier.size(20.dp)
                )
            }

            Row {
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share Profile",
                        tint = Color(0xFF1C1B1B),
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = Color(0xFF1C1B1B),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = FrameBorder, thickness = 1.dp)

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            // Header Section
            item(span = { GridItemSpan(3) }) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(76.dp)
                        ) {
                            AsyncImage(
                                model = "https://lh3.googleusercontent.com/aida-public/AB6AXuDMDM3WhU5E2Z1-Ux2CRIYd-ey3Ico5eQ9qt4fS-6s5qWv5GakNTGovYosNS4fPhWCxL2XJ6s1aFZEtLHEPHeT-g0fx6pRkuz8YtflhKYQV12eOjK5f9M3aae-0YVr44dgYSCTVgIJ-nRLNMpdvRF7Os1PneaeYIK-uhryO3EJCRfw0eWpjGbE397obMv4U-VsRL0Lg6oDSSI-ZWLMe8ICPeEaGfu4PSDNDw0g7KZ9gGQf0RjxYllqFFnKRkVmXyntY7LHajDWQKg",
                                contentDescription = "Elena Vance Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, FrameBorder, CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(FramePrimary)
                                    .align(Alignment.BottomEnd),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Edit photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(20.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Elena Vance",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1C1B1B)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "(she/her)",
                                    fontSize = 12.sp,
                                    color = FrameTextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFEBE7E7))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "Active in Kyoto Field Notes",
                                    fontSize = 11.sp,
                                    color = FramePrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Visual anthropologist & architectural photographer. Chasing raking afternoon light through post-war European brutalism.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = FrameTextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Stats Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "5", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1C1B1B))
                            Text(text = "Challenges", fontSize = 11.sp, color = FrameTextMuted)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "8", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1C1B1B))
                            Text(text = "Shared Stories", fontSize = 11.sp, color = FrameTextMuted)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "34", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1C1B1B))
                            Text(text = "Process Guides", fontSize = 11.sp, color = FrameTextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {},
                            shape = RoundedCornerShape(18.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Edit Profile", fontSize = 12.sp, color = Color(0xFF1C1B1B))
                        }

                        OutlinedButton(
                            onClick = {},
                            shape = RoundedCornerShape(18.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Quiet Preferences", fontSize = 12.sp, color = Color(0xFF1C1B1B))
                        }
                    }
                }
            }

            // Tabs Row
            item(span = { GridItemSpan(3) }) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFFCF9F8),
                    contentColor = FramePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = FramePrimary
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { viewModel.setProfileTab(0) },
                        text = {
                            Text(
                                "Creations 14",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { viewModel.setProfileTab(1) },
                        text = {
                            Text(
                                "Stories 8",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { viewModel.setProfileTab(2) },
                        text = {
                            Text(
                                "Saved 23",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 2) Color(0xFF1C1B1B) else FrameTextMuted
                            )
                        }
                    )
                }
            }

            // Grid photos
            items(photos) { photo ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clickable { viewModel.navigateTo(ScreenDestination.POST_PROCESS) }
                ) {
                    AsyncImage(
                        model = photo.url,
                        contentDescription = "Profile creation",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (photo.hasProcessBadge) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Tune,
                                contentDescription = "Process available",
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    if (photo.isStack) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Collections,
                                contentDescription = "Multi-photo story",
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
