package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.FramePrimary
import com.example.ui.theme.FrameTextMuted
import com.example.ui.theme.FrameTextSecondary
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.ScreenDestination

data class CommunitySubmission(
    val author: String,
    val imageUrl: String,
    val likes: Int
)

@Composable
fun ChallengeDetailScreen(
    viewModel: FrameViewModel,
    modifier: Modifier = Modifier
) {
    val submissions = listOf(
        CommunitySubmission(
            author = "@marcus_grain",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDOW7h4uHdoAJX_geYfoNkkbf86aH3-y4ZWmC6-NN3sW9m9SEHBn_Go90t3OSZyF8LvR3eyXyUFFO5Ppzy2XMGMw8f_IHESGGjOgCXltpXoEGzDpuKoJSgQSJvmskWm9a2reduOicmIqto8x31DJOfXNcyCK7-fmzetWnRxQI_1ValcrvvTctQ92_R0yVNbdQA906Tdiu04bIeOZYq79OwwJN4S6iFoyZji60QFf52u6N2HOjaRg5pQ1-ylidWT2ygn0GHmqx7ukg",
            likes = 42
        ),
        CommunitySubmission(
            author = "@elena.s",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAZJqYlEYy72j4UJ5XpuccX5qr5mns1LWo1yg95tC6QyQAkOn5cyQnIfjFFxGxOZjVVtUhPvvrRtkuTl0U91B62N0fZJoADAtCsmWRMO9MZBc6CEJFNUy3hMXNFD5clplubiRG37BYa8SiQglGLYEue_uyq8xd2-uO5nJ_ZNc9yyjs4f7UE1uS45E6qDDHtvpjoHcUfN97lVAS_I6Ijp6Aobbi5_P21f8JiDs3V8i8h5EKu84i4PmdpF5KgCUkqZ2c9dQVSKRYLlA",
            likes = 38
        ),
        CommunitySubmission(
            author = "@julian_noir",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDI_ZyFmmT0a3Xh79_pEqceAc0KVSSYt_i6ctLF78AYH2G3YEJr2tPeCO_0ycImR9ni0GApQgLTnk09Du8MazpEcRpCh7juFURiaa6uzLShCwrXCSVf0tsmFjJ0EeZ0E6JUgJU0MBgFegTSUktMc7DPw9S11HSKab6SG9d3mTMaORGbcILiAO4Skq3kuif6chT5eO5bnE_MTWR0TlM6WOhiu7m3jJ108a5vbCG1bAOfg7gNV1OoD1NGzsD2ZJ1Bw3brrPE8kZIDUw",
            likes = 65
        ),
        CommunitySubmission(
            author = "@anouk_photo",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBoEB2nrb1Q9qA_EJ216bLQGE-hMeJGQPzE2IPsqqlYdUevTXxnav0xYbClN5mgqQi7uc9Aa6TJDn8R6ItKwWYXLk98QxS8_YgoQl5xBWWoay-vOTPzyA9PXir6n640nWYXKm_HRGzJHKRZwGw6UA4KApZeEPJEAx6OG8RERshTzA8jDiSJDzA536iPoFiytFif6bPH36HgcLI7GlDtExPvvFpyqt7yWAQsfJQ_MSgJi4v93nnvH4Yfy3T13j9hxbjtZjS1A4ZElg",
            likes = 29
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFCF9F8))
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("challenge_detail_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF1C1B1B)
                )
            }

            Text(
                text = "Challenge",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1B)
            )

            Row {
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = Color(0xFF1C1B1B)
                    )
                }
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Outlined.MoreVert,
                        contentDescription = "More",
                        tint = Color(0xFF1C1B1B)
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Hero section
            item(span = { GridItemSpan(2) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    AsyncImage(
                        model = "https://lh3.googleusercontent.com/aida-public/AB6AXuDJMxdieP69xAl_TFyYX3OV0EnvWHz45V8WNwRtf4PQYam2fA8U2-e6nyL8Piu6R3u-MPmINWKgkijYCRsM-ouOpGdQ0PpxUIq7f2oBE8sCqvmC5DIEpgarprINL-gYAu2AB0ObZU_neArTUC8gCPV1_NJdiS0ZyG40_BySSaUJY2zX96pb78AD2drJW-wDk5rgOjh7jDjySzREzlBT8Nd_PIHcX1iZUfQu0AtQox8PXW4LjOU-E749snKwHkJvasx6ewi0a-TKWQ",
                        contentDescription = "Cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(FramePrimary)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Street Photography Room",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Your city after dark",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = Color.White
                        )
                        Text(
                            text = "4 days left • 342 joined",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Prompt Box
            item(span = { GridItemSpan(2) }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF6F3F2)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Prompt: Nocturnal textures & ambient reflections",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1C1B1B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "How does your city transform when the streetlights buzz on? Look for neon spill, wet asphalt, empty train platforms, or solitary silhouettes.",
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = FrameTextSecondary
                        )
                    }
                }
            }

            // Your submission card
            item(span = { GridItemSpan(2) }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuBghu6awmvv5u99byT-2UHC7GBrmGA92URMZNPRc1GkQDxUU05ayPtVo0Il3pSIDuMPTUu2ceuYeJQILKS1M79CWuRFy-g0KsgE42kC97QdssxRN-rkAvhRZQBKep8N4R3IA5BKbOW2BAB5UwMfwuJogLJPTxaoOWR8bpQBzKGLqkAsV7p72vG3gZ2D1C8OGGMtNcQf0m1GutYJtfxpzDckxL9CbjQ_PhKvLgsp2Z6z72FT1P5bfnoaEPi-Q0D9PpYgZ9X19yTpmg",
                            contentDescription = "Your submission",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "YOUR SUBMISSION",
                                color = FramePrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Rain on wet asphalt",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1C1B1B)
                            )
                            Text(
                                text = "Sony A7IV • 35mm f/1.4 • ISO 800",
                                fontSize = 11.sp,
                                color = FrameTextMuted
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.navigateTo(ScreenDestination.NEW_CREATION) },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Update", fontSize = 11.sp, color = Color(0xFF1C1B1B))
                        }
                    }
                }
            }

            // Submissions header
            item(span = { GridItemSpan(2) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "COMMUNITY PERSPECTIVES (342)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FrameTextMuted,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "Most Recent",
                        fontSize = 11.sp,
                        color = FramePrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Grid items
            items(submissions) { sub ->
                Column(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .clickable { viewModel.navigateTo(ScreenDestination.POST_PROCESS) }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                    ) {
                        AsyncImage(
                            model = sub.imageUrl,
                            contentDescription = sub.author,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(8.dp))
                        )

                        // Likes badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Likes",
                                    tint = Color.White,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${sub.likes}",
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = sub.author,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1C1B1B)
                    )
                }
            }

            // Bottom Submit Button
            item(span = { GridItemSpan(2) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(ScreenDestination.NEW_CREATION) },
                        colors = ButtonDefaults.buttonColors(containerColor = FramePrimary),
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("submit_perspective_button")
                    ) {
                        Text(
                            text = "Submit a Perspective",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
