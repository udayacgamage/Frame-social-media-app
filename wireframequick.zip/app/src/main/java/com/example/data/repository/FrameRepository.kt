package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.ChallengeEntity
import com.example.data.model.PostEntity
import com.example.data.model.RoomEntity
import com.example.data.model.StoryMomentEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class FrameRepository(context: Context) {
    private val database = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "frame_database"
    ).build()

    private val dao = database.frameDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        scope.launch {
            seedInitialDataIfNeeded()
        }
    }

    val allPosts: Flow<List<PostEntity>> = dao.getAllPosts()
    val allRooms: Flow<List<RoomEntity>> = dao.getAllRooms()
    val allChallenges: Flow<List<ChallengeEntity>> = dao.getAllChallenges()

    fun getStoryMoments(storyId: String): Flow<List<StoryMomentEntity>> {
        return dao.getMomentsForStory(storyId)
    }

    suspend fun toggleLike(postId: String) {
        val posts = dao.getAllPosts().first()
        val target = posts.find { it.id == postId } ?: return
        val newLiked = !target.isLiked
        val newCount = if (newLiked) target.likesCount + 1 else target.likesCount - 1
        dao.updatePost(target.copy(isLiked = newLiked, likesCount = newCount))
    }

    suspend fun toggleBookmark(postId: String) {
        val posts = dao.getAllPosts().first()
        val target = posts.find { it.id == postId } ?: return
        dao.updatePost(target.copy(isBookmarked = !target.isBookmarked))
    }

    suspend fun toggleJoinRoom(roomId: String) {
        val rooms = dao.getAllRooms().first()
        val target = rooms.find { it.id == roomId } ?: return
        dao.updateRoom(target.copy(isJoined = !target.isJoined))
    }

    suspend fun toggleJoinChallenge(challengeId: String) {
        val challenges = dao.getAllChallenges().first()
        val target = challenges.find { it.id == challengeId } ?: return
        val newJoined = !target.isJoined
        val newCount = if (newJoined) target.joinedCount + 1 else target.joinedCount - 1
        dao.updateChallenge(target.copy(isJoined = newJoined, joinedCount = newCount))
    }

    suspend fun addStoryMoment(storyId: String, authorHandle: String, caption: String, photoUrl: String, location: String) {
        val moment = StoryMomentEntity(
            id = "moment_${System.currentTimeMillis()}",
            storyId = storyId,
            authorHandle = authorHandle,
            timestamp = "Just now",
            location = location,
            photoUrl = photoUrl,
            caption = caption,
            reactionPill1 = "✨ Magic light 1",
            commentsCount = 0
        )
        dao.insertMoment(moment)
    }

    suspend fun createPost(caption: String, roomName: String, photoUrl: String) {
        val newPost = PostEntity(
            id = "post_${System.currentTimeMillis()}",
            authorName = "Elena Vance",
            authorHandle = "elena_v",
            authorAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDMDM3WhU5E2Z1-Ux2CRIYd-ey3Ico5eQ9qt4fS-6s5qWv5GakNTGovYosNS4fPhWCxL2XJ6s1aFZEtLHEPHeT-g0fx6pRkuz8YtflhKYQV12eOjK5f9M3aae-0YVr44dgYSCTVgIJ-nRLNMpdvRF7Os1PneaeYIK-uhryO3EJCRfw0eWpjGbE397obMv4U-VsRL0Lg6oDSSI-ZWLMe8ICPeEaGfu4PSDNDw0g7KZ9gGQf0RjxYllqFFnKRkVmXyntY7LHajDWQKg",
            roomName = roomName,
            photoUrl = photoUrl,
            caption = caption,
            likesCount = 0,
            commentsCount = 0,
            isLiked = false,
            timestamp = "Just now"
        )
        dao.insertPost(newPost)
    }

    private suspend fun seedInitialDataIfNeeded() {
        val existingPosts = dao.getAllPosts().first()
        if (existingPosts.isEmpty()) {
            val initialPosts = listOf(
                PostEntity(
                    id = "post_1",
                    authorName = "milo_lens",
                    authorHandle = "milo_lens",
                    authorAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDobuu7cvuIdyUsa3diPmHeOsydIsme19Fd9nmC4dM0H6PJ4gYWdMqvL9X101TTBF5TTzyW-UWGWELh3FoJMHb2KPBDs5r8--P9djcUTDn8HzxD2eXbPSqflky4CBG0ReDWM4lEHRq_UCz5Ch5kFpOVljbzo04DF6ZcdjxTrSMX3pqsdBuU7yYBRvfQsPpNtdYN2DSH2PaSVFQVV0Ios1fv85duWCeQ-lZxOVrQf2g3BrgiDLb3XopwB7aCK3wmK785aDZGpMJcWQ",
                    coAuthorName = "clara_art",
                    coAuthorHandle = "clara_art",
                    roomName = "Street Photography",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDQVMMzKwDq_hIbX61uJ8xPaDKmx9KR885KCV9cs3ufIxXXUmXOO0fCxDcqDtRlPKz-Iw4_C1JkmR73ahRtzsFncOYiMt5lvwm_dEQwFbrSJ6PaZHFx9wfEa9uL65ZgrgucUs2a3QZTZQ0snr9ZkHQs76sSgmLEAY0M-H4l0BhhSpEYOZiMtd7hjhQap86FJg27A3mZcIZPF2UVp2T_QibuE7hmJSqkHqskCBVlx3MwlGcyePavitRj3XTEIfyfYFbKTzJpQ8tNIg",
                    caption = "Geometric intersections at noon. Developed in Room #4 with Clara's grading preset.",
                    likesCount = 482,
                    commentsCount = 24,
                    isLiked = true
                ),
                PostEntity(
                    id = "post_2",
                    authorName = "sarah_bakes",
                    authorHandle = "sarah_bakes",
                    authorAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDpdU8n27tIk0IuRYGCnaATqolu_b9RHKvOr2if26Z8qy6SA74KlFvdLPgnvr5KzkXBD43Bbnqtnlt5ZOrCeyVe5CWaU5BLJPM2esdcuqFDd9umMlD6xfquMpMJMUyhvQ_YNlJcyWyhydqdiMd-mHOcOQEa8LPjUV1DVIHfwE6ZxeN4w3zOENwqbWD83TkG4a9HkQsBqEOTJlV7VWEVH0rjLh6ZIAXlzzCLHCNYPYkk6_08-QZEC7UTXfyKYuT4lIKDSela2pFErQ",
                    roomName = "Home Cooking",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDZqIt8MuWtG9iPU2I-IbAp0BNrx80p1xtukIveJ8jMxKSJnvhflxg4pG8vzzQidLnljvjmvVqWNG2t22soJmlTVD4YkAsZv6tzev6xarqfKF7Y2t2jAVKxIc1rUV5084pb-s3OVhqo1GtC8Sb-iBB-r0pfzlk1MVdRkGYE6s7HpgOuSI2QWum6I2sYqLDj-P2gNnzNJncOikPVVs0PI12CmE-ZIbUAhaiOLPpOtixWRghCD683-8uWEy4K-JLn_tjbM7W4as_EjQ",
                    caption = "82% hydration country loaf after a 24h cold ferment. Swipe through process stages for crumb structure notes.",
                    likesCount = 319,
                    commentsCount = 18,
                    processStagesCount = 3,
                    isLiked = false
                ),
                PostEntity(
                    id = "post_3",
                    authorName = "Elena Vance",
                    authorHandle = "elena_v",
                    authorAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBoHxbAxMax8M47qEMnZLNNH-T8OpkT0zVA471vkqcOiF5SjfBSnDslwBOZCGs2WCrIEX9IFIlpB0aHGnS-tBDQSNx6uWIiHPQCkFCBeVLzCP2dzJUEsgl5nU2Gt-MPF4otdr6Y_XSiaCteFyKplCwJxcRANd9f-d-iSww_j3HABJjNkA5m1UsXpVtvRrS2oCQ2qswMp_Dvbv3h1EfzWJBmfxzIi5IoyHmT6ofW69hkx822gTLfsmxc7Cqzp6aIvCBm8ruhxsM7JQ",
                    roomName = "Street Photography",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAJCd9W8asKFGdlU462f97KLir0O9_qKaScStYmPSO8PgdsVz_g1TDiTb14p26BTVAPHv3gf_KFHGUgbQbHo7Hp7iR0TY_f1EmL51HR1aHzp68cYA6nzobXhwWmvOl34IG7UU0gwAR6RKfudm7ljIq2ctItZLW9dzd1Agpv3PZbABFJuenK8KxC-eAGmjrbFygDhraMXd5Dcg9HZVMaDyh7eTHR6GdS4ZaB_PzgW-KI7PjiFOQ1KJy8jbmTlDFmy1AGxkLUsXh9mw",
                    rawPhotoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDr3guoVmV99k1a30wsI4AMDT6EHEIkBnZrKBzbG7_9dQFxHj4UPnti9PhFB3ar-zGp-L69FPvKyNwkQb-mvfQLN9o2oZy99HDtHOluuriG4hGiJ0zlWTD6w-0Pkh4GVHOYjgvbwq_ZgUHugdXiejN5t0MZR9UrIbfTfUYhF4vHDzBr5okeuci4hvNOlzC_AE21fly4_lbl8aogKIe_3_T2JvQ2tp5yCSeMrGsv4WhP5ld10g_FUUb67jwlpB2ryVCU-C6L_h9VbA",
                    caption = "Dappled Brutalism: Exposing for Highlights. Developed with custom Lightroom tone curve.",
                    likesCount = 540,
                    commentsCount = 12,
                    processStagesCount = 3,
                    techSpecs = "Leica Q2 • 28mm f/5.6 • 1/500s • ISO 200 • -1.0 EV",
                    isLiked = false
                ),
                PostEntity(
                    id = "post_4",
                    authorName = "Mateo Reyes",
                    authorHandle = "mateo_visuals",
                    authorAvatarUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCoQff03LnhNJNRFrR0pYw8gRQKYev9j5RkDocyJtfIUqXLAkAwKOMshFHVs6SdYGh63IOWwRuGycG8S-df3BKKTMJBXByFi0BE8bTyErwliII1ycXi79h9ZIC7fiNFB_aMX_-iFIJIuCWtdsdcQXYzHM96fW87_eLf36fVCrGxe9DGltkCuqitEadK0DyXgF-Orpif70L_BDwmSfu1-YHDysGoBYxAb0oS228-MNhpl0k1SNfYphwiOUxdYSHOBN0Zt-lX3uIopQ",
                    roomName = "Street Photography",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCEQldQ5nJZ2psZC4m2NHtn70o308oTnYPPiUr1jmptYIp7LXGw4ePstj0UVgHlCSWHHsw3VtEW2Rki8Xr-_xcfYnrlUwjic_f0CsVDgWqFyghHKkjB6rVJDHIHNtqjlr_Xvcege9VYLM9Q-F6graoMmv2LJQzVkQ7-q9z8EqYygZURna5pl1twfsQD6wBG-qONLWnl_M3Lt1vvR16c4hzXSiHecssKOKEuCxdfKeJ7RPsoDjwdZtNByUQhdY2_0OQXDWMsKCiQYw",
                    caption = "First light slicing through the U-Bahn overpass. The fog cleared just as the commute started.",
                    likesCount = 348,
                    commentsCount = 24,
                    techSpecs = "Shot at 28mm f/8 • 1/500s • ISO 400",
                    location = "Berlin, Germany",
                    isLiked = true
                )
            )
            dao.insertPosts(initialPosts)
        }

        val existingRooms = dao.getAllRooms().first()
        if (existingRooms.isEmpty()) {
            val initialRooms = listOf(
                RoomEntity(
                    id = "room_street",
                    name = "Street Photography",
                    description = "Chasing fleeting moments, urban geometry, and shadows across global streets. Strictly original 35mm & digital work.",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBciLOWFL5ZYR_89o0WU85NqPe75G6DBnAkC4kbU5qxsTHILVOjaejxSKBSkRvhnRij1NfizdFntL94sRpJ8v-4iPHgaYDNCWn4BHRH1IhEY-rdMb2Y8vmLjKrqgSyg-ZGSHuvRfYxlRS3BvieUgqPcPnthZkx0dzauIQmIrntrrSBXZguW0y_dXV96p-4NJCynjnKIn7CDX9EtxOfN9ubvGxeazNsa5pPrTjvM81adJZU2qvR8R8sl-a0dbi3MFzdZPG_UPWy6Aw",
                    membersCount = "14.2k members",
                    activeCount = 82,
                    isJoined = true,
                    isFeatured = true,
                    category = "Photography"
                ),
                RoomEntity(
                    id = "room_cooking",
                    name = "Home Cooking",
                    description = "From beginner doughs to regional fermentation. Share process, fails, and feast notes.",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuC-s_FMLrPkkyJa1qO39uedKD1W1YmXOBv4UqAo3_nQVy7T56O4tV9feYTKaokpvgl67mCZnUFzqzFt1whQogeFVZIW6smVtCSEjE0DH2NgpIVZnXJaV9S_sjnMgm97qoSaxjkdI2LC5nd1XBYnl3DiA692AO_Lrr8eYorYxySxvhiX4G5jK9lh1ekQqeUgKsev-afHQjQ3nUifHO5DMGmFtLbSg0p4DhyO5yZaS8vZ7B0YXZkQE2pge8Yo8C9ON5k--gdcWWQzcw",
                    membersCount = "9.8k members",
                    activeCount = 45,
                    isJoined = true,
                    isFeatured = false,
                    category = "Culinary"
                ),
                RoomEntity(
                    id = "room_weekend",
                    name = "Weekend Explorers",
                    description = "Local hikes, weekend roadtrips, and collaborative trail journals.",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAx1BWrPmnqTndZZ_RXu6CqyR4kmgjRyxvIpFXolh_dQkK6aEjZHK9-OS4FwBxqzidCTr22YA1wKSU_lfP5PZPDBEmXXwieb7H6Bobr9810ZmnQyY_f_QmZudqtPaoE_An542b11g5zZV9a9-Uv0uM64ZPOm6apd-L9bLBy1eNitG4EltFO1N_VZ3dw9cSAaOBFHkWIXPWVePHuMKjtm0tkRPOLbJVnpziZqPQYtnvxnCgZrS9mhn9MSpL7N7eO6l_3ig1PmxdBHg",
                    membersCount = "18.5k members",
                    activeCount = 110,
                    isJoined = false,
                    isFeatured = false,
                    category = "Visual Arts"
                ),
                RoomEntity(
                    id = "room_digital",
                    name = "Digital Art & Shaders",
                    description = "Generative art, 3D modeling, and creative coding experiments.",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuA3l9fxVdZ7L-pfY9GeQFooX33jkNVBJ-uDtKZ_0SPPGxQKAmt38bJUXUEuqiWpIDHWDbs-Uw_ta6Brx_nknp_PjFpwseX0nk51IwQg7xZHxbZw8lR467k8-W-ZjRyMJQnGej-RaOpf8o6XOd_5ZFJQDLVK6a9WNMlqIyMdtVj3TxSJgLLU8d8A2zC-4qnIPeCZZi-LjP665y8V_q_riiqbebwGYc8BvnxBOYGRr_rUg-fWspzTHqN-k0z84zMLiQOSHX5VCEut_g",
                    membersCount = "6.4k members",
                    activeCount = 29,
                    isJoined = false,
                    isFeatured = false,
                    category = "Visual Arts"
                )
            )
            dao.insertRooms(initialRooms)
        }

        val existingChallenges = dao.getAllChallenges().first()
        if (existingChallenges.isEmpty()) {
            val initialChallenges = listOf(
                ChallengeEntity(
                    id = "chal_1",
                    title = "Your city after dark",
                    roomName = "Street Photography Room",
                    daysRemaining = 4,
                    joinedCount = 342,
                    prompt = "Prompt: Nocturnal textures & ambient reflections",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDAm4H2_o_Tb95w40en9zcJ7TehQavWMU-zWjytN0EvBEr-7xxqFIBmIFevbqUf1ALTin7mNP3RBpZW5gfrPeGbOParILYu7v07AbiyfZ2kbMPF2M5726DqZ1DH5CD1A9MPvUc6LGThxnAa3Zyvzn92LQNeu4t7SpHls_GdyqFq2HONaAP5ZT9tZzjuZpMwrw1WDJsIjNTy-Pgq8BJGznhreQcxWzMOxpUBcnRbxTohUQ9hylYnLOcDLXNVFwwnPYJgn9Spki12nA",
                    isJoined = true,
                    category = "Photography"
                ),
                ChallengeEntity(
                    id = "chal_2",
                    title = "Cook with 5 ingredients",
                    roomName = "Home Cooking Room",
                    daysRemaining = 6,
                    joinedCount = 189,
                    prompt = "Prompt: Honest simplicity on the plate",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuB2kn57F3Yr0-8PvR7vJNiXdtdKJj1kxdi_jR6Doxes4Oe1alulLwksyDpd8xDP0miJ2whga-Oz3sY3h6H664YUhFjpbtajPbxU0D5km4yUJfdYM9UspU2yEZjhwakOIbLcUZ2xT75wN0jvmyJHsKM9FE1xDRJbR3qaVdrtuGWne8sF_FJUJSUTDAqe-rYgvKYCO13sAGRUFwe85kcAAN5PWiUxsPuVVE2Il0L6JXJMKpDo3jzKoHbpmUOnR0_QQncN4ZsY8a5Y8g",
                    isJoined = false,
                    curator = "Curated by Chef Soren",
                    category = "Culinary"
                ),
                ChallengeEntity(
                    id = "chal_3",
                    title = "Find beauty in ordinary things",
                    roomName = "Mindful Making",
                    daysRemaining = 12,
                    joinedCount = 512,
                    prompt = "Prompt: Fleeting light on daily objects",
                    coverUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuB7YjP9HSMN4L6qteE_yeSf6_oDeFyXCOaJ87zbatzL96cJdayJGrscMoeIyT7BKD1k1t9kat3hJeDFMEc3AvQogHollI_XH3_PYvIcXJbB5bAH1WM3mGyLdESx16-b4DkOlGuH-xplyXY7BqM9UNEWx80d7GLgym0VkRdcEHgJjOfmOalI6Dbqs7P0Tn_9bun49qLs3R2wJgToWMZ0XDYBT5IXFOz8r8iVxYwmGWvhqsMU1sC6gE-pO289WbjmUety4kO8uMG-Dg",
                    isJoined = false,
                    curator = "Weekly community open",
                    category = "Art"
                )
            )
            dao.insertChallenges(initialChallenges)
        }

        val existingMoments = dao.getMomentsForStory("ella_weekend").first()
        if (existingMoments.isEmpty()) {
            val initialMoments = listOf(
                StoryMomentEntity(
                    id = "moment_1",
                    storyId = "ella_weekend",
                    authorHandle = "@chloe.lens",
                    timestamp = "Fri 6:20 AM",
                    location = "Nine Arch Bridge",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuBSuC1BiEQgpprNKjQjFiNecXF0Dv3wP0ZVd3DOuakEMOiUucX15K3bWlR3yLLaYfCLh8AuI3ub7lGtlFU49IfDe1CeTQZIg8fDiZzhZFm4TYTWLTwqPYQyg_PJCuOMsCMSg1Upr3cix3LmmllWFC_ReQ92fhVbQLScSOj8prkc0ex0Zi43yCgJIu3fcR091mNHPHuO5C2jJBmwO39VnulCIyfirf1cIb_rcdCC2bkJuakAqrMxRDQkEGOyOInMlMZiguJm9INKJg",
                    caption = "The valley was completely silent until the steam whistle cut through the morning fog. Worth the 5:00 AM climb through damp tea bushes.",
                    reactionPill1 = "✨ Magic light 8",
                    reactionPill2 = "🔥 Inspiring 14",
                    commentsCount = 12
                ),
                StoryMomentEntity(
                    id = "moment_2",
                    storyId = "ella_weekend",
                    authorHandle = "@marcus_k",
                    timestamp = "Sat 11:15 AM",
                    location = "Ceylon Tea Trail",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDdewfFoVMdfHf0-4EelOdDzN8zIsgHFJKYBICXWhQhmfjAMbSN_oFCr7Imp7e44ejRtlW7xFcNRdXRCZl-rWMzaj2qeZscYbXQjC7salJcGy4W04A0350oIg9L1BtbOJ_VWcbSQ4gaQs9jeOZev-2cXUyUo2J64pLgPvNVY9JeCqWnryGvGvtFyv-ENYPe5Lzu2jjsXhE-2Lg3tfy3R3bUeAUq_g2Nlvf8wy-6EZNrrLxOnALkh2OX-UBJTdwuouAdoHqGuMbGBg",
                    secondaryPhotoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuClJuvRxLKuJSZ1wxWAQHgC8FSBO3oHp0y7HIvSv5L91J_-zt1c-qVN33PCdZYWE8YHAGBafVvJP3PAMg3C7tJAANrQQqAYRtp4G4pmMyL0rueoCa0gNy_ox2dM0kyxQhkPR29LRF1EYzOeH3olBveruO6J6uJdpUfODHZ3omSI_rC0tIlnCLkkgbqxabBWACQ9BgzG6rKpOtHLNooYS70l-gQsiuwuM04m3rwehaMd9PjY1_3QINhUNDuslkxnIimtM99l6y1-ig",
                    caption = "Miles of emerald terraces. We stopped at a weathered shack midway for fresh spiced pekoe tea.",
                    reactionPill1 = "🍃 Serene 5",
                    commentsCount = 4
                ),
                StoryMomentEntity(
                    id = "moment_3",
                    storyId = "ella_weekend",
                    authorHandle = "@elena_v",
                    timestamp = "Sun 7:40 PM",
                    location = "Little Adam's Peak",
                    photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCzkGJ9XqdIpSNfV8yYpA6kTCJ0WMvhDcgxwYrHXFV1w2rzAVFy4VtKCbxxy_dMi_bqnZufJUbc2Rc3XB_cR-iWvF-zP0mGUDs0nqutozNpiV4xqf755lptQzrXt_wdCPmVstCcOPH0UyyPDCVaXQOtOcp1kwSK0ArhWe0kRkFo1tfqo7y-RkUCM707MWONyD1F4BXkUFUp4tOto65QZ8hee8DYTuPgE-25Dt1wOU3RiyB_6HD6ST-NBAOlpjKoFS-rT-6PD0ENWQ",
                    caption = "The last light catching Ella Rock across the gorge. The winds were ferocious, but keeping the tripod steady paid off.",
                    reactionPill1 = "⛰️ Epic 19",
                    reactionPill2 = "❤️ 7",
                    commentsCount = 9
                )
            )
            dao.insertMoments(initialMoments)
        }
    }
}
