package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val authorName: String,
    val authorHandle: String,
    val authorAvatarUrl: String,
    val coAuthorName: String? = null,
    val coAuthorHandle: String? = null,
    val roomName: String,
    val photoUrl: String,
    val rawPhotoUrl: String? = null,
    val caption: String,
    val likesCount: Int,
    val commentsCount: Int,
    val isLiked: Boolean = false,
    val isBookmarked: Boolean = false,
    val processStagesCount: Int? = null,
    val techSpecs: String? = null,
    val location: String? = null,
    val timestamp: String = "2h ago"
)

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val coverUrl: String,
    val membersCount: String,
    val activeCount: Int = 0,
    val isJoined: Boolean = false,
    val isFeatured: Boolean = false,
    val category: String = "Photography"
)

@Entity(tableName = "challenges")
data class ChallengeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val roomName: String,
    val daysRemaining: Int,
    val joinedCount: Int,
    val prompt: String,
    val coverUrl: String,
    val isJoined: Boolean = false,
    val curator: String? = null,
    val category: String = "Photography"
)

@Entity(tableName = "story_moments")
data class StoryMomentEntity(
    @PrimaryKey val id: String,
    val storyId: String,
    val authorHandle: String,
    val timestamp: String,
    val location: String,
    val photoUrl: String,
    val secondaryPhotoUrl: String? = null,
    val caption: String,
    val reactionPill1: String? = null,
    val reactionPill2: String? = null,
    val commentsCount: Int = 0
)

data class ProcessStep(
    val stepNumber: Int,
    val title: String,
    val category: String,
    val description: String,
    val badges: List<String> = emptyList(),
    val microCardTitle: String? = null,
    val microCardSubtitle: String? = null,
    val colorPills: List<Pair<String, Long>> = emptyList() // Label to Color hex
)

data class CommentItem(
    val authorName: String,
    val timestamp: String,
    val content: String,
    val replyCount: String? = null
)
