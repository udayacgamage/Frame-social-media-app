package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.viewmodel.FrameViewModel
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.ScreenDestination
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Frame", appName)
  }

  @Test
  fun `viewModel initialization and navigation flow`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = FrameViewModel(app)

    assertEquals(NavigationTab.HOME, viewModel.currentTab.value)
    assertEquals(ScreenDestination.HOME_FEED, viewModel.currentScreen.value)

    viewModel.selectTab(NavigationTab.ROOMS)
    assertEquals(NavigationTab.ROOMS, viewModel.currentTab.value)
    assertEquals(ScreenDestination.ROOMS_DISCOVER, viewModel.currentScreen.value)

    viewModel.navigateTo(ScreenDestination.POST_PROCESS)
    assertEquals(ScreenDestination.POST_PROCESS, viewModel.currentScreen.value)

    viewModel.navigateBack()
    assertEquals(ScreenDestination.ROOMS_DISCOVER, viewModel.currentScreen.value)
  }
}
